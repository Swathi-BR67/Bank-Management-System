
/************************************************************************************
 *   FILENAME    :   bankapp.c
 *
 *   DESCRIPTION :   This file is used as Main menu of the banking system.
 *
 * ***********************************************************************************/

#include <stdio.h>   //Including required Header files
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <pthread.h>
#include <time.h>
#include <termios.h>
#include "bankapp.h"

#define MAXPW 32



void gotoxy(int x, int y) // Sets co-ordinates in (x,y)
{
	printf("%c[%d;%df",0x1B,y,x);
}


/***********************************************************************************
			// This is the Main function.
************************************************************************************/

int main()               
{
	
	customer_file_to_list(); //Calling file to list function of customer corner
	
	start=ptr=last=prev=new2=NULL; //Declares all pointer of customer structure as NULL
	
	start1=last1=ptr1=new1=NULL; //Declares all pointer of transaction structure as NULL
	
	int choice=0;
	int Banker_pass=0;
	
	while(choice!=3)
	{
	        system("clear");
		printf("\n__________________________\n\n");
		printf("\n\n---------WELCOME----------\n");
		printf("\n-----------To-------------\n");
		printf("\n ---The Banking System--- \n\n");
		printf("\n__________________________\n\n");
		printf("\n1. Customer Corner \n2. Banker Corner \n3. Exit \n");
		printf("\nEnter Your Choice\n");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1: Customer_Corner();  // Calling Customer_Corner function
				break;
				
			case 2: Banker_pass=checkpassword(); // Check banker's password
				if(Banker_pass==1)
				{
					printf("\nINVALID PASSWORD!!\n");
					continue;
				}
				else
				{
					Banker_Corner();  // Calling Banker_Corner function
				}
				break;
				
			case 3: return EXIT_SUCCESS; 
			default: printf("\nInvalid Choice\n");
		}
	}
	
	if(start)
		customer_list_to_file(); // Calling  the list to file function of customer corner

	if(start1)
		banker_list_to_file();  //Calling list to file  function for bankers corner

  system("read a");
}

int Create_Account() //This functions create an account

{
	char name[30];
	char aadhar_no[10];
	char customer_id[20];
	int len=0;
	char password[10];;
	char account_type[10];
	double amount;
	new2 = (cust *) malloc(sizeof(cust)); //Dynamic memory allocation for customer structure
	printf("\n\n Create Your Account\n");
	while(1)
	{
		//Taking input of customer name
		printf("\nEnter Your Name:\n");
		fflush(stdin);
		scanf("%s",name);
		int len;
		int flag=0;
		for(int i=0;name[i];i++)
		{
			if(!isalpha(name[i])) //isalpha() function is used to check if user gives numbers in name section then it will not accept the name 
			{
				flag=1;
				break;
			}
		}
		if(flag==1)
		{
			printf("Invalid name.Name should contain only alphabets\n"); 
			continue;
		}
		len=strlen(name);
		if(len<5||len>15) //Checking that length of the name should be less than 5 and greater than 15
		{
			printf("Invalid Length.Length should not exceed 15 charecters\n");
			continue;
		}
		else
		{
			break;
		}
	}
		int an,flag=0;
		while(1)
		{
		
			//Taking input of addhar no
			printf("\nEnter aadhar no:\n");
			scanf("%d",&an);
			for(ptr=start;(ptr);ptr=ptr->next)
			{
				if(ptr->aadhar_no==an)
				{
					flag=1;
					break;
				}
			}
			if(flag==1)
			{
				printf("already exist");
				return 0;
			}
			if(an<100000|| an>999999) //Checking if the length of the aadhar no should be 6 digits only else it will print invalid message
			{
				printf("\nInvalid Length.Length should only of 6 digits.\n"); 
				continue;
			}

			
			else{
				break;
			}
		}
			sprintf(aadhar_no,"%d",an); //stores integer in string

//	printf("\nEnter your password: \n");
//	scanf("%s",password);
        char *pr=getpassword(); //storing password in pointer

	while(1)
	{
		//Taking input of account type
		printf("\nEnter your account type:\n");
	        scanf("%s",account_type);
		if((strcmp(account_type,"SA")==0) ||(strcmp(account_type,"CA")==0)) //To check account type. It should be SA or CA.
		{
	
			break;
		}
		else{
			printf("\nInvalid account type\n");
		     continue;
		}
	}

	while(1)
	{
		//Taking the input of amount
        	printf("\nEnter your amount:\n");
	        scanf("%lf",&amount);	
			if((strcmp(account_type,"SA")==0 && amount <5000) || (strcmp(account_type,"CA")==0 && amount < 10000)) //Checking if Account type is SA and then amount should be greater than 5000 and if account type is CA then amount should be greater than 10000
			{
				printf("\nMinimum amount should be less than 5000 SA and less than 10000 for CA\n");
				continue;
			}
			else
			{
				break;
			}
	}

       	strcpy(customer_id,account_type); //Copying account type in customer id
        strcat(customer_id,aadhar_no); //Concatinate customer id and addhar no

	strcpy(new2->name,name); // Storing local variable of name in pointer of customer structure
	strcpy(new2->customer_id,customer_id); //Storing  local customer_id in pointer of customer structure
	new2->aadhar_no=atoi(aadhar_no); //Typecasting and storing it in pointer
	strcpy(new2->password,password); //storing password in pointer of customer structure
	strcpy(new2->account_type,account_type); //Storing accont type in pointer of customer structure
	new2->balance=amount; //storing amount in pointer

	printf("\nYour account is created successfully!!!!\n");
	
        printf("\nThis is your customer id: %s\n",customer_id); 
	if(!start) 
	{
		start=new2;
		new2->next=NULL;
	}
	else if(strcmp(new2->customer_id, start->customer_id)<0)
	{
		new2->next=start;
		start=new2;
	}
	else
	{
		for(ptr=start;(ptr) &&(strcmp( ptr->customer_id, new2->customer_id)<0);prev= ptr ,ptr=ptr->next);
		prev->next=new2;
		new2->next=ptr;
	}
	printf("\n");
}


int View_Balance() //View balance of customer by accepting customer id
{
	if(!start) //checking if list is empty
	{
		printf("\nThere are no records in system\n");
		return(1);
	}
	char m_customer_id[20];
	printf("\nEnter Customer id:\n");
	scanf("%s",m_customer_id);
	for(ptr=start;(ptr)&& (strcmp(ptr->customer_id,m_customer_id)!=0);ptr=ptr->next);

	if(!ptr) //if pointer id NULL then customer is not found
	{
		printf("\n %s Customer id not found\n",m_customer_id);
		return(1);
	}
	printf("\nBalance is %7.2lf\n",ptr->balance);
	
}

 int customer_file_to_list() //Inserting recrods from file to list
{
//	cust *last;
	FILE *fp;                                    //File  Pointer
	if((fp=fopen("Customer_File","rb")) == NULL) //Opening a binary file for reading
	{
		return (1);
	}
	new2 = (cust *)calloc(1,sizeof(cust));        //Allocating Dynamic memory 
	fread(new2,sizeof(cust),1,fp);                //reading file
	while(!feof(fp))
	{
		//after reading data from file , inserting into the linked list
		if(!start) 
		{
			start=last=new2;
			new2->next=NULL;
		}
		else
		{
			last->next=new2;
			last=new2;
			new2->next=NULL;
		}
		new2=(cust *) calloc(1,sizeof(cust)); //Dynamically allocating memory
		fread(new2,sizeof(cust),1,fp);         //reading file
	}
}



int customer_list_to_file() //For inserting records in customer file from list
{
	FILE *fp;                                    //File pointer
	fp=fopen("Customer_File","wb");              //opening the binary file in write mode
	for(ptr=start; (ptr);ptr=ptr->next)          
	{
		fwrite(ptr,sizeof(cust),1,fp);       //Writing in file 
	}
	fclose(fp);                                 //closing the file
}


int Get_Customer_Report() //View customer report 
{
	//after reading data from file ,inserting into the linked list
	if(!start)
	{
		printf("\nEmpty File...No records in file\n");
		return(1);
	}
	printf("\n--Customer Report--\n");
	printf("\n CUSTOMER_ID    AADHAR_NO      NAME    PASSWORD    ACCOUNT_TYPE     BALANCE\n\n");  
	for(ptr=start;(ptr);ptr=ptr->next)
	{
		printf("\n %s        %d        %s         %s        %s         %8.21f \n",ptr->customer_id,ptr->aadhar_no,ptr->name,ptr->password,ptr->account_type,ptr->balance);
	}
	
  
}


int Edit_Customer() //Edit the details of customer details with all validations
{
	char  m_customer_id[20];
	int flag=0;
	char name[30];
	char  m_account_type[10];
	char m_aadhar_no[10];

	printf("\nEnter the customer id\n");
	scanf("%s",m_customer_id);
	for(ptr=start; (ptr) &&(strcmp(ptr->customer_id,m_customer_id)!=0);ptr=ptr->next);


	if(!ptr)
	{
		printf("\n%d Customer id not found\n",m_customer_id);
		return(1);
	}
	printf("\nThe old customer name %s , account type %s and balance of customer id %s is %7.21f\n",ptr->name,ptr->account_type,ptr->customer_id,ptr->balance);

	while(1)
	
	{
		sprintf(m_aadhar_no,"%d",ptr->aadhar_no);
		//Taking input of customer name
		printf("\nEnter Your Name:\n");
		fflush(stdin);
		scanf("%s",name);
		int len;
		int flag=0;
		for(int i=0;name[i]!='\0';i++)
		{
			if(!isalpha(name[i])) //isalpha() function is used to check if user gives numbers in name section then it will not accept the name 
			{
				flag=1;
				break;
			}
		}
		if(flag==1)
		{
			printf("Invalid name.Name should contain only alphabets\n"); 
			continue;
		}
		len=strlen(name);
		if(len<5||len>15) //Checking that length of the name should be less than 5 and greater than 15
		{
			printf("Invalid Length.Length should not exceed 15 charecters\n");
			continue;
		}
		else
		{
			break;
		}
	}
	while(1) //edit account type
	{	
		printf("\nEnter the new account type\n");
		scanf("%s",&m_account_type);
		if((strcmp(m_account_type,"SA")==0) || (strcmp(m_account_type,"CA")==0))
		{

			if(strcmp(m_account_type,"CA")==0)
			{
				if(ptr->balance<10000)
				{
					printf("\nMinimum account balance of CA should be more than Rs10000\n");
					continue;
				}
				else
				{
					strcpy(ptr->account_type,m_account_type);
					strcpy(ptr->customer_id,m_account_type);
					strcat(ptr->customer_id,m_aadhar_no);
					printf("New account type : %s",ptr->customer_id);

					break;
				}
			}
			else if(strcmp(m_account_type,"SA")==0)
			{

				strcpy(ptr->account_type,m_account_type);
				strcpy(ptr->customer_id,m_account_type);
				strcat(ptr->customer_id,m_aadhar_no);
				printf("\nNew account type : %s",ptr->customer_id);
				break;
			}
		}
		else
		{
			printf("\nInvalid account type\n");
			continue;
		}
	}
	strcpy(ptr->name,name);
}

int Delete_Customer() //Delete customer details
{
	if(!start)
	{
		printf("\nEmpty Records\n");
		return(1);
	}
	char  m_customer_id[20];
	printf("\nEnter the Customer id\n");
	scanf("%s",m_customer_id);
	if(strcmp(m_customer_id,start->customer_id)==0)
	{
		ptr=start;
		start=ptr->next;
		free(ptr);
	}
	else
	{
		for(ptr=start;(ptr) &&(strcmp (ptr->customer_id,m_customer_id)!=0);prev=ptr,ptr=ptr->next);
		if(!ptr)
		{
			printf("\n%s Customer id not found\n",m_customer_id);
			return(1);
		}
		printf("\nThe record of customer id %s deleted succesfully\n\n",ptr->customer_id);
		prev->next=ptr->next;
		free(ptr);
	}
}


int banker_file_to_list() //For insering records in list from banker file
{
	tr *last;         //last pointer
	FILE *fp;
	if((fp=fopen("Transaction_File","rb"))==NULL)  //Opening the binary file in read mode
	{
		printf("\nEmpty File...No records in file\n");
		return 1;
	}
	new1=(tr *)calloc(1,sizeof(tr)); //Dynamically allocating memory for new1 for bankers
	fread(new1,sizeof(tr),1,fp);     //reading file
	while(!feof(fp))
	{
		//after reading data from file inserting into linked list
		if(!start1)
		{
			start1=last=new1;
			new1->next=NULL;
		}
		else
		{
			last->next=new1;
			last=new1;
			new1->next=NULL;
		}
		new1=(tr *)calloc(1,sizeof(tr));
		fread(new1,sizeof(tr),1,fp);
	}
}


int banker_list_to_file()
{ 
	FILE *fp;                                  //File pointer
	fp=fopen("Transaction_File","wb");         //opening the binary file in write mode
	for(ptr1=start1;(ptr1);ptr1=ptr1->next)    //appending data at the end
	{
		fwrite(ptr1,sizeof(tr),1,fp);      //writing in file banker
	}
	fclose(fp);  //closing the file
}

int Get_Transaction_Report() //display transaction report
{

	if(!start1)
	{
		printf("Empty List\n");
		return(1);
	}
	printf("\n--Transaction Report--\n");
	printf("\n SOURCE   DESTINATION    AMOUNT\n\n");
	for(ptr1=start1;(ptr1);ptr1=ptr1->next)
	{
 
		printf("\n %s         %s           %7.21f \n",ptr1->saccount,ptr1->daccount,ptr1->amt);
	}
	
}

pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER; //Initialize mutex
pthread_t thread_id; //Initialize thread id

int Customer_Corner()
{
	int choice=0;
	while(choice!=4)
	{

//		system("clear");
		printf("\n___________________\n\n");
		printf("\n   Customer Corner \n ");
		printf("\n1. Create Account\n");
		printf("\n2. Do Transaction\n");
		printf("\n3. View Balance\n");
		printf("\n4. Back to Menu\n");
		printf("\n___________________\n\n");
		printf("\n   Enter your choice:");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1 : Create_Account(); // calls Create_Account from Function.c
				 break;
			case 2 : pthread_create(&thread_id,NULL,Do_Transaction,NULL); // starting a new thread in function calling process
				 pthread_join(thread_id,NULL); // this provides a mechanism allowing an application to wait for thread to terminate
				 break;
			case 3 : View_Balance();    // calls View_Balance from Function.c
				 break;
			case 4 : break;            //returns to main menu in The Banking System 
			default : printf("\nInvalid Choice\n");
		}
	}
}

int Banker_Corner()
{
	int choice=0;
	while(choice!=6)
	{
	//	system("clear");
		printf("\n_______________________\n\n");
		printf("\n Banker's Corner\n");
		printf("1. Edit Customer Details\n");
		printf("2. Delete Customer Details\n");
		printf("3. Do Transfer\n");
		printf("4. Get Transaction Report\n");
		printf("5. Get Customer Report\n");
		printf("6. Back to Menu\n");
		printf("\n_________________________\n\n");
		printf("\nEnter your Choice:\n");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1 : Edit_Customer();   // calls Edit_Customer from Function.c
				 break;
			case 2 : Delete_Customer();  // calls Delete_Customer from Function.c
				 break;
			case 3 :pthread_create(&thread_id,NULL, Do_Transfer,NULL);// calls Do_Transfer from Function.c
			        pthread_join(thread_id,NULL);
				 break;
			case 4 : Get_Transaction_Report();  // calls from Get_Transaction_Report from Function.c
				 break;
			case 5 : Get_Customer_Report(); // calls Get_Customer_Report from Function.c
				 break;
			case 6 : break;
			default : printf("\n Invalid Choice\n");
		}
	}
}
int Do_Transaction()//allows user to withdraw and deposit amount
{
	int token,auto_token;
	time_t t1;
	int choice=0;
	double amount=0;
	char m_customer_id[20];
	double b_amount=0;
	printf("\nEnter\n1: Withdraw\n2. Deposit\n3. Back to menu\n");
	scanf("%d",&choice);
	if(choice==3)
		return 0;
	printf("\nEnter your Customer id\n");
	scanf("%s",m_customer_id); 
	for(ptr=start;(ptr);ptr=ptr->next)
	{
		if(strcmp(ptr->customer_id,m_customer_id)!=0)
		{

			printf("\n Customer ID  not found!!!\n");
			return 0;
		}
	}
	srand((unsigned) time(&t1));//generates a random unique number for token
	auto_token=rand() % 50;
        pthread_mutex_lock(&lock); //release mutex object
	printf("\n Your token for current transaction is %d\n",auto_token);
	pthread_mutex_unlock(&lock); //lock a mutex object which identifies a mutex
	printf("\n PLEASE CONFIRM YOUR TOKEN\n");
	scanf("%d",&token);
	if(token==auto_token)//checks the token 
	{

		if(choice==1)//withdraw option
		{
			for(ptr=start;(ptr)&&(strcmp(ptr->customer_id,m_customer_id)!=0);ptr=ptr->next);
			if(ptr==NULL)//checks if pointer is null then it will print id is not found else it will do transaction 
			{
				printf("\n%s Customer id is not Found\n",m_customer_id);

				return 0;
			}
			else
			{
				printf("\nAvailable balance is: %7.2lf\n",ptr->balance);
				while(1)
				{
					printf("\nEnter Amount to withdraw:\n ");
					scanf("%lf",&amount);
					b_amount=ptr->balance-amount;


					if((strcmp(ptr->account_type,"SA")==0 && b_amount <5000) || (strcmp(ptr->account_type,"CA")==0 && b_amount < 10000)) //checks if account typr is SA then amount should be greater than 5000 and if account type is CA then amount should be greater than 10000.
					{
						printf("\nCannot Withdraw amount....Low Balance\n");
						break;
					}
					else if((strcmp(ptr->account_type,"SA")==0 && amount >50000) || ((strcmp(ptr->account_type,"CA")==0) && amount > 100000)) //check if account type is SA then amount should be less than 50000 and if account type is CA then amount should be less than 100000.
					{
						printf("\nAmount cannot be greater than 50000 for Savings Account and 100000 for Current Account\n");
						continue;
					}
					else
					{
						ptr->balance = ptr->balance-amount; //Storing transaction in pointer
						printf("\nCurrent Balance: %7.2lf\n",ptr->balance);
						printf("\nRs. %lf Withdrawn\n",amount);
						break;
					}
				}

			}
		}
		if(choice==2)//Deposit Option
		{
			for(ptr=start;(ptr)&&(strcmp(ptr->customer_id,m_customer_id)!=0);ptr=ptr->next);

				if(ptr==NULL) //checks if customer id is valid if not then it will print customer id not found
				{
					printf("\n%s Customer id not found\n",m_customer_id);

					return 0;
				}
				else
				{
					while(1)

					{
						printf("\nEnter Amount to deposit:\n ");
						scanf("%lf",&amount);
						if((strcmp(ptr->account_type,"SA")==0 && amount >50000) || ((strcmp(ptr->account_type,"CA")==0) && amount > 100000))//checks the condition if account type is SA then amount should be less than 50000 and if account type is CA then amount should be less than 100000
						{
							printf("\nAmount cannot be greater than 50000 for Savings Account and 100000 for Current Account\n");
							continue;
						}
						else
						{
							ptr->balance = ptr->balance+amount;//storing transaction in pointer
							printf("\nCurrent Balance: %7.2lf\n",ptr->balance);
							printf("\nRs. %lf Deposited\n",amount);
							break;
						}


					}
				}
			}

	}
	else
	{
		return 0;
	}
}

int Do_Transfer()// Transfer money from one account to another account
{
	char saccount[15];
	char daccount[15];
	double amt;
	int token,auto_token;
	time_t t1;
	tr *new1=(tr *)malloc(sizeof(tr));//Dynamic memory allocation for transaction
	double amount=0,after_balance=0;
	int Banker_Pass=0;
	Banker_Pass=checkpassword(); //storing the password
	if(Banker_Pass==1)//checking the password and if its wroong it wiil print invalid password
	{
		printf("\nINVALID PASSWORD!!!\n");
		return 0;
	}
	else
	{

		printf("\n-------Transfor Money-------\n");


		printf("\nSource Account Customer ID-\n");
		scanf("%s",saccount);
		for(ptr=start;(ptr);ptr=ptr->next)
		{
			if(strcmp(ptr->customer_id,saccount)!=0)
			{

				printf("\n Source account not found!!!\n");
				return 0;
			}
		}
		printf("\nDestination Account Number/Id\n");
		scanf("%s",daccount);
		for(ptr=start;(ptr);ptr=ptr->next)
		{
			if(strcmp(ptr->customer_id,daccount)!=0)
			{

				printf("\n Destination  account not found!!!\n");
				return 0;
			}
		}
		printf("\nEnter Amount To Transfer\n");
		scanf("%lf",&amt);
		srand((unsigned) time(&t1)); //generates random unique token no
		auto_token=rand() % 50;
                pthread_mutex_lock(&lock); //lock mutex object
	
		printf("\n YOUR TOKEN FOR CURRENT TRANSACTION IS %d\n",auto_token);
                pthread_mutex_unlock(&lock); //release mutex object
		printf("\n PLEASE CONFIRM YOUR TOKEN\n");
		scanf("%d",&token);
		if(token==auto_token) //checks the token number
		{
			for(ptr=start;(ptr);ptr=ptr->next)
			{
				if((strcmp(ptr->customer_id,saccount)==0))
				{
					after_balance=ptr->balance-amt;
					while(1)
					{
						if((strcmp(ptr->account_type,"SA")==0 && after_balance<5000) || (strcmp(ptr->account_type,"CA")==0 && after_balance < 10000)) //checks if account type is SA then amount should be greater than 5000 and if account type is CA then amount should be greater than 10000
						{
							printf("Can't Transfer. You are at low balance\n");
							continue;
						}

						if((strcmp(ptr->account_type,"SA")==0 && amt >50000) || (strcmp(ptr->account_type,"CA")==0 && amt > 100000)) //checks if account type is SA then amount should be less than 50000 and if account type is CA then amount should be less than 100000
						{
							printf("Amount cannot be greater than 50000 for Savings Account and 100000 for Current Account");
							continue;
						}
						else
						{
							printf("After deduction %7.2lf\n",after_balance);
							ptr->balance = ptr->balance-amt;//storing the amount in pointer	
							printf("Rs. %lf Debited\n",amt);
							printf("Current Balance: %7.2lf\n",ptr->balance);
							break;
						}
					}

				}

				if(strcmp(ptr->customer_id,daccount)==0)
				{
					ptr->balance=ptr->balance+amt;//storing amount in pointer
					printf("Rs. %7.2lf credited to account\n",amt);
					printf("Your balance is Rs. %7.2lf\n",ptr->balance);
					return 0;

				}
			}
		}
		else
		{
			printf("\n INVALID TOKEN!!!!!\n");
			return 0;
		}
		strcpy(new1->saccount,saccount);//storing local variable of source account  in structure variable to create linked list
		strcpy(new1->daccount,daccount);//storing local variable of destination account in structure variable to create linked list
		new1->amt=amt;
		if(!start1)//empty list
		{
			start1=new1;
			last1=new1;
			new1->next=NULL;


		}
		else
		{
			last1->next=new1;
			last1=new1;
			new1->next=NULL;

		}
		printf("\n");
	}
}

ssize_t password(char **pw,size_t sz,int mask,FILE *fp)

{     
	if(!pw || !sz||!fp)return -1;   // validate input
#ifdef MAXPW
	if(sz> MAXPW) sz=MAXPW;
#endif

	if(*pw==NULL)                // reallocate if no address 
	{

		void *tmp = realloc(*pw,sz * sizeof **pw);
		if(!tmp)
			return -1;
		memset (tmp,0,sz);  // initialize memory to 0
		*pw = (char*)tmp;
	}
	size_t idx = 0;         // index number of chars in read
	int c = 0;
	struct termios old_kbd_mode; // orig keyboard settings
	struct termios new_kbd_mode;
	if(tcgetattr (0,&old_kbd_mode)) // save orignal settings
	{
		fprintf(stderr, "%s() error: tcgetattr failed.\n",__func__);
		return -1;
	}   // copy old to new
	memcpy(&new_kbd_mode, &old_kbd_mode,sizeof(struct termios));
	new_kbd_mode.c_lflag &= ~(ICANON | ECHO); //new kbd flags
	new_kbd_mode.c_cc[VTIME] = 0;
	new_kbd_mode.c_cc[VMIN] = 1;
	if(tcsetattr (0, TCSANOW, &new_kbd_mode)){
		fprintf(stderr, "%s() error: tcsetattr failed.\n",__func__);
		return -1;
	}
	// read chars from fp , mask if valid char specified
	while(((c=fgetc(fp)) != '\n' && c != EOF && idx <sz - 1)||(idx ==sz - 1 && c==127))
	{
		if(c != 127){
			if(31 < mask && mask <127)//valid ascii char
				fputc(mask,stdout);
			(*pw)[idx++] = c;
		}
		else if(idx > 0)  //handle backspace (del)
		{
			if (31 < mask && mask < 127){
				fputc(0x8,stdout);
				fputc(' ',stdout);
				fputc(0x8,stdout);
			}
			(*pw)[--idx] = 0;
		}
	}
	(*pw)[idx] = 0; // null-terminate
	// reset original keyboard
	if(tcsetattr(0,TCSANOW,&old_kbd_mode)){
		fprintf(stderr,"%s() error: tcsetattr failed.\n",__func__);
		return 1;
	}
	if(idx == sz-1 && c!='\n')  // warn if pw truncate
		fprintf(stderr,"(%s() warning: truncated at %zu chars.)\n",__func__,sz -1);
	return idx;  // number of chars in password
}
int checkpassword() //Validating passwords for banker corner
{
	char pw[MAXPW]={0};
	char *p=pw;

	FILE *fp=stdin;
	ssize_t nchr=0;
	nchr=password(&p,MAXPW,'*',fp);

	//Taking input for password
	printf("\nEnter password:\n");
	nchr=password(&p,MAXPW,'*',fp);
	if(strcmp(p,"abc@123")==0 || strcmp(p,"xyz@345")==0) //checking the fixed password
	{
		return 0;
	}
	else
	{
		return 1;
	}


}
char * getpassword()
{
	char pw[MAXPW]={0};
	pt=pw;

	FILE *fp=stdin;
	ssize_t nchr=0;
	nchr=password(&pt,MAXPW,'*',fp);
	//Taking Input password
	printf("\nEnter passowrd:\n");
	nchr=password(&pt,MAXPW,'*',fp);
	return pt;
}
